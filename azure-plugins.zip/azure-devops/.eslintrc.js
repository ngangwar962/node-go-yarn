module.exports = require('../../.eslintrc.cjs');
