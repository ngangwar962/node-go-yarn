# @backstage-community/plugin-scaffolder-backend-module-azure-devops

## 0.6.0

### Minor Changes

- ff23f2f: Backstage version bump to v1.36.1

## 0.5.0

### Minor Changes

- 2ca3917: Backstage version bump to v1.35.1

## 0.4.0

### Minor Changes

- 52190f0: Backstage version bump to v1.34.1

## 0.3.0

### Minor Changes

- 5b2427d: Adds support for template parameters to the `azure:pipeline:run` action

## 0.2.0

### Minor Changes

- 7ce46dc: Backstage version bump to v1.33.5

## 0.1.2

### Patch Changes

- 0880746: Updated code with proper TSDoc comments to generate API Reports

## 0.1.1

### Patch Changes

- 28110f5: Introduced the `azure:pipeline:run` scaffolder action
