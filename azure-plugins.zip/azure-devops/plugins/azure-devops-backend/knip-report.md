# Knip report

## Unused dependencies (4)

| Name                             | Location     | Severity |
| :------------------------------- | :----------- | :------- |
| @backstage/plugin-catalog-common | package.json | error    |
| @backstage/plugin-catalog-node   | package.json | error    |
| @backstage/plugin-auth-node      | package.json | error    |
| @backstage/catalog-model         | package.json | error    |

## Unused devDependencies (1)

| Name          | Location     | Severity |
| :------------ | :----------- | :------- |
| @types/lodash | package.json | error    |
