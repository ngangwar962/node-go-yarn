# Knip report

## Unused devDependencies (2)

| Name                 | Location     | Severity |
| :------------------- | :----------- | :------- |
| @testing-library/dom | package.json | error    |
| canvas               | package.json | error    |
