# Knip report

## Unused devDependencies (1)

| Name                          | Location     | Severity |
| :---------------------------- | :----------- | :------- |
| @backstage/backend-test-utils | package.json | error    |
