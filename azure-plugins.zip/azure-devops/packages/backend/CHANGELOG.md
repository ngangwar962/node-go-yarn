# backend

## 0.0.12

### Patch Changes

- Updated dependencies [28110f5]
  - @backstage-community/plugin-scaffolder-backend-module-azure-devops@0.1.1

## 0.0.11

### Patch Changes

- Updated dependencies [dab2f81]
  - @backstage-community/plugin-azure-devops-backend@0.7.3
  - @backstage-community/plugin-catalog-backend-module-azure-devops-annotator-processor@0.1.2
  - app@0.0.10

## 0.0.10

### Patch Changes

- Updated dependencies [2dd98b6]
  - @backstage-community/plugin-azure-devops-backend@0.7.2
  - @backstage-community/plugin-catalog-backend-module-azure-devops-annotator-processor@0.1.1
  - app@0.0.8

## 0.0.9

### Patch Changes

- Updated dependencies [1b55b99]
  - @backstage-community/plugin-azure-devops-backend@0.7.1

## 0.0.8

### Patch Changes

- Updated dependencies [c6f00d3]
  - @backstage-community/plugin-catalog-backend-module-azure-devops-annotator-processor@0.1.0
  - @backstage-community/plugin-azure-devops-backend@0.7.0
  - app@0.0.7

## 0.0.7

### Patch Changes

- Updated dependencies [b6515fa]
  - @backstage-community/plugin-azure-devops-backend@0.6.12
  - @backstage-community/plugin-catalog-backend-module-azure-devops-annotator-processor@0.0.4
  - app@0.0.5

## 0.0.6

### Patch Changes

- Updated dependencies [ae2ee8a]
  - @backstage-community/plugin-azure-devops-backend@0.6.11

## 0.0.5

### Patch Changes

- Updated dependencies [968258f]
  - @backstage-community/plugin-azure-devops-backend@0.6.10

## 0.0.4

### Patch Changes

- Updated dependencies [d33c708]
  - @backstage-community/plugin-azure-devops-backend@0.6.9
  - app@0.0.4

## 0.0.3

### Patch Changes

- Updated dependencies [31aba58]
  - @backstage-community/plugin-azure-devops-backend@0.6.8
  - app@0.0.3

## 0.0.2

### Patch Changes

- Updated dependencies [2deaaa0]
- Updated dependencies [f31e04a]
  - @backstage-community/plugin-azure-devops-backend@0.6.7
  - app@0.0.2

## 0.0.1

### Patch Changes

- Updated dependencies [82b799b]
- Updated dependencies [fef765e]
- Updated dependencies [0a6bae4]
- Updated dependencies [0032b05]
  - @backstage-community/plugin-azure-devops-backend@0.6.6
  - app@0.0.1
