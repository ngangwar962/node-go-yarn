# Knip report

## Unused dependencies (11)

| Name                                  | Location     | Severity |
| :------------------------------------ | :----------- | :------- |
| @backstage/plugin-search-backend-node | package.json | error    |
| @backstage/plugin-permission-common   | package.json | error    |
| @backstage/plugin-permission-node     | package.json | error    |
| @backstage/plugin-auth-node           | package.json | error    |
| @backstage/config                     | package.json | error    |
| better-sqlite3                        | package.json | error    |
| dockerode                             | package.json | error    |
| node-gyp                              | package.json | error    |
| winston                               | package.json | error    |
| app                                   | package.json | error    |
| pg                                    | package.json | error    |
