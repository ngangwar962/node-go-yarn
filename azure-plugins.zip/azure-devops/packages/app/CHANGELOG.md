# app

## 0.0.10

### Patch Changes

- Updated dependencies [dab2f81]
  - @backstage-community/plugin-azure-devops@0.6.1

## 0.0.9

### Patch Changes

- Updated dependencies [904a6a2]
  - @backstage-community/plugin-azure-devops@0.6.0

## 0.0.8

### Patch Changes

- Updated dependencies [2dd98b6]
  - @backstage-community/plugin-azure-devops@0.5.1

## 0.0.7

### Patch Changes

- Updated dependencies [c6f00d3]
  - @backstage-community/plugin-azure-devops@0.5.0

## 0.0.6

### Patch Changes

- Updated dependencies [45fd620]
  - @backstage-community/plugin-azure-devops@0.4.10

## 0.0.5

### Patch Changes

- Updated dependencies [b6515fa]
  - @backstage-community/plugin-azure-devops@0.4.9

## 0.0.4

### Patch Changes

- Updated dependencies [d33c708]
  - @backstage-community/plugin-azure-devops@0.4.8

## 0.0.3

### Patch Changes

- Updated dependencies [31aba58]
  - @backstage-community/plugin-azure-devops@0.4.7

## 0.0.2

### Patch Changes

- Updated dependencies [8276458]
- Updated dependencies [2deaaa0]
  - @backstage-community/plugin-azure-devops@0.4.6

## 0.0.1

### Patch Changes

- Updated dependencies [0a6bae4]
- Updated dependencies [0032b05]
  - @backstage-community/plugin-azure-devops@0.4.5
