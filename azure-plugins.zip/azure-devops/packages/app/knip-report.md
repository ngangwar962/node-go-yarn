# Knip report

## Unused dependencies (2)

| Name         | Location     | Severity |
| :----------- | :----------- | :------- |
| react-router | package.json | error    |
| react-use    | package.json | error    |

## Unused devDependencies (3)

| Name                        | Location     | Severity |
| :-------------------------- | :----------- | :------- |
| @testing-library/user-event | package.json | error    |
| @backstage/test-utils       | package.json | error    |
| @testing-library/dom        | package.json | error    |
