# Catalog Backend Module for Azure

This is an extension module to the plugin-catalog-backend plugin, providing extensions targeted at Azure cloud offerings.

## Getting started

See [Backstage documentation](https://backstage.io/docs/integrations/azure/org) for details on how to install
and configure the plugin.
