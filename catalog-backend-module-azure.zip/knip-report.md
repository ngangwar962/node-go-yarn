# Knip report

## Unused devDependencies (1)

| Name  | Location     | Severity |
| :---- | :----------- | :------- |
| luxon | package.json | error    |

